<form id="profileForm" method="post" enctype="multipart/form-data">
   <table cellpadding="4" width="100%" cellspacing="0">
      <tbody>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="employeeID" data-value="Staff ID" size="32" title="Staff ID" placeholder="Staff ID"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="firstname" data-value="Firstname" size="32" title="Firstname" placeholder="Firstname"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="lastname" data-value="Lastname" size="32" title="Lastname" placeholder="Lastname"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="middlename" data-value="Middlename" size="32" title="Middlename" placeholder="Middlename"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" class="date-pick dp-applied" name="dob" data-value="Date of Birth" size="32" title="Date of Birth" placeholder="Date of Birth"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="phonenumber" data-value="Phonenumber" size="32" title="Phonenumber" placeholder="Phonenumber"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="personalEmail" data-value="Personal Email" size="32" title="Personal Email" placeholder="Personal Email"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top">
               <select class="select2" name="maritalStatus">
                  <option value="" selected="selected">Marital Status</option>
                  <option value="Single">Single</option>
                  <option value="Married">Married</option>
               </select>   
            </td>
            <td valign="bottom"><input type="text" class="form-control" name="homeCity" data-value="Home City" size="32" title="Home City" placeholder="Home City"></td>
            <td valign="bottom"><input type="text" class="form-control" name="homeState" data-value="Home State" size="32" title="Home State" placeholder="Home State"></td>
         </tr>
         <tr>
            <td val="" ign="top">
               <p>Home Address<br><textarea class="form-control"  name="homeAddress" cols="35" rows="6"></textarea></p>
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="lastQualification" data-value="Last Qualification Obtained" size="32" title="Last Qualification Obtained" placeholder="Last Qualification Obtained"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="courseStudied" data-value="Course Studied" size="32" title="Course Studied" placeholder="Course Studied"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="institution" data-value="Last Institution Attended" size="32" title="Last Institution Attended" placeholder="Last Institution Attended"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top">
               <p>Trainings Attended<br><textarea class="form-control"  name="trainings" cols="35" rows="6"></textarea></p>
            </td>
            <td val="" ign="top">
               <p>Professional Certifications<br><textarea class="form-control"  name="professionalCerts" cols="35" rows="6"></textarea></p>
            </td>
            <td val="" ign="top">
               <p>Professional Membership<br><textarea class="form-control"  name="professionalMembership" cols="35" rows="6"></textarea></p>
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="nokName1" data-value="Next of Kin Name (1)" size="32" title="Next of Kin Name (1)" placeholder="Next of Kin Name (1)"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="nokRelationship1" data-value="Next of Kin Relationship (1)" size="32" title="Next of Kin Relationship (1)" placeholder="Next of Kin Relationship (1)"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="nokPhone1" data-value="Next of Kin Phone Number (1)" size="32" title="Next of Kin Phone Number (1)" placeholder="Next of Kin Phone Number (1)"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top">
               <p>Next of Kin Address (1)<br><textarea class="form-control"  name="nokAddress1" cols="35" rows="6"></textarea></p>
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="nokName2" data-value="Next of Kin Name (2)" size="32" title="Next of Kin Name (2)" placeholder="Next of Kin Name (2)"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="nokRelationship2" data-value="Next of Kin Relationship (2)" size="32" title="Next of Kin Relationship (2)" placeholder="Next of Kin Relationship (2)"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="nokPhone2" data-value="Next of Kin Phone Number (2)" size="32" title="Next of Kin Phone Number (2)" placeholder="Next of Kin Phone Number (2)"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top">
               <p>Next of Kin Address (2)<br><textarea class="form-control"  name="nokAddress2" cols="35" rows="6"></textarea></p>
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="refName" data-value="Referee Name" size="32" title="Referee Name" placeholder="Referee Name"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="refEmail" data-value="Referee EMail" size="32" title="Referee EMail" placeholder="Referee EMail"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="refPhone" data-value="Referee Phone Number" size="32" title="Referee Phone Number" placeholder="Referee Phone Number"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="refAddress" data-value="Referee Address" size="32" title="Referee Address" placeholder="Referee Address"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="refAName3" data-value=" Referee(3) Name" size="32" title=" Referee(3) Name" placeholder=" Referee(3) Name"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="refName2" data-value="Referee (2) Name" size="32" title="Referee (2) Name" placeholder="Referee (2) Name"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="refPhone2" data-value="Referee (2) Phone Number" size="32" title="Referee (2) Phone Number" placeholder="Referee (2) Phone Number"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="refEmail2" data-value="Referee (2) EMail" size="32" title="Referee (2) EMail" placeholder="Referee (2) EMail"><br>    </td>
         </tr>
         <tr>
            <td colspan="3">
              <p>&nbsp;</p>
               <h4>BANKING DETAILS</h4>
               <hr size="1">
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="refAddress2" data-value="Referee (2) Address" size="32" title="Referee (2) Address" placeholder="Referee (2) Address"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="previousEmployer" data-value="Previous Employer" size="32" title="Previous Employer" placeholder="Previous Employer"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top">
               <p>Previous Employer Contact Address<br><textarea class="form-control"  name="pEmployerAddress" cols="35" rows="6"></textarea></p>
            </td>
            <td val="" ign="top" ><input type="text" class="form-control" name="pEmployerEmail" data-value="Previous Employer Contact Email" size="32" title="Previous Employer Contact Email" placeholder="Previous Employer Contact Email"><br>    </td>
         </tr>
         <tr>
            <td colspan="3">
              <p>&nbsp;</p>
               <h4>RSA/SSSNIT DETAILS</h4>
               <hr size="1">
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="pEmployerPhone" data-value="Previous Employer Contact Phone" size="32" title="Previous Employer Contact Phone" placeholder="Previous Employer Contact Phone"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="bankName" data-value="Bank Name" size="32" title="Bank Name" placeholder="Bank Name"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="NubanNumber" data-value="Nuban Number" size="32" title="Nuban Number" placeholder="NUBAN Number"><br>    </td>
         </tr>
         <tr>
            <td colspan="3">
               &nbsp;
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="AccountName" data-value="Account Name" size="32" title="Account Name" placeholder="Account Name"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="bankBranch" data-value="Bank Branch" size="32" title="Bank Branch" placeholder="Bank Branch"><br>    </td>
         </tr>
         <tr>
            <td colspan="3">
               &nbsp;
            </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" name="pensionAdministratorName" data-value="Pension Administrator Name" size="32" title="Pension Administrator Name" placeholder="Pension Administrator Name"><br>    </td>
            <td val="" ign="top"><input type="text" class="form-control" name="pensionAdministratorAccountNumber" data-value="Pension Administrator Account Number" size="32" title="Pension Administrator Account Number" placeholder="Pension Administrator Account Number"><br>    </td>
         </tr>
         <tr>
             <td>&nbsp;</td>
         </tr>
         <tr>
             <td colspan="3">
                <h4>OTHER DETAILS</h4>
                 <hr size=1 />
             </td>
         </tr>
         <tr>
            <td val="" ign="top"><input type="text" class="form-control" class="date-pick dp-applied" name="resumptionDate" data-value="Resumption Date" size="32" title="Resumption Date" placeholder="Resumption Date"><br>    </td>
         </tr>
         <tr>
            <td val="" ign="top<br"></td>
         </tr>
         <tr>
            <td colspan="1"><strong>Work Tools In Possession</strong></td>
            <td></td>
         </tr>
         <tr>
             <td><label><input name="workToolsInPossession" type="checkbox" value="Blackberry">&nbsp;Blackberry</label>&nbsp;&nbsp;<label><input name="workToolsInPossession" type="checkbox" value="Official Car">&nbsp;Official Car</label>&nbsp;&nbsp;<label><input name="workToolsInPossession" type="checkbox" value="Laptop">&nbsp;Laptop</label>&nbsp;&nbsp;<label><input name="workToolsInPossession" type="checkbox" value="Laptop Bag">&nbsp;Laptop Bag</label>&nbsp;&nbsp;<label><input name="workToolsInPossession" type="checkbox" value="ID Card">&nbsp;ID-card</label></td>
         </tr>
         <tr>
             <td>
               <input type="text" class="form-control" name="laptopSerialNo" data-value="Laptop Serial No" size="32" title="Laptop Serial No" placeholder="Laptop Serial No"><br>
               <br>
             </td>
         </tr>
         <tr>
             <td>Passport Photograph: <br><input type="file" name="photograph"><br>    <br></td>
         </tr>
         <tr>
             <td>
               <input type="text" class="form-control" name="refEmail3" data-value="Ref Email3" size="32" title="Ref Email3" placeholder="Referee Email"><br>    <br>
             </td>
             <td>   <input type="text" class="form-control" name="refPhone3" data-value="Ref Phone3" size="32" title="Ref Phone3" placeholder="Referee Phone"><br>    <br></td>
         </tr>
         <tr>
            <td colspan="3">
                <h4>Dependents&nbsp;<a class="btn btn-dark btn-sm" data-toggle="modal" href="#dependentModal">ADD</a><hr size=1 /></h4>
                <br />
                
                    <table id="dependentGrid" class="table table-striped table-bordered table-sm">
                        <tbody>
                            <tr><td colspan="4">No dependents registered. <a data-toggle="modal" href="#dependentModal">Add dependent.</a></td></tr>
                        </tbody>
                    </table>
            </td>
         </tr>
         <tr>
            <td><label><input name="confirmedCorrect" type="checkbox" value="YES" checked="checked">&nbsp;<strong>The information provided has been confirmed correct</strong></label></td>
         </tr>
      </tbody>
   </table>
   <br>
   <p>&nbsp;</p>
   
   <p><input type="reset" class="reset hide"></p>
   <a class="btn btn-primary" onclick="saveProfile()">Save Profile</a>&nbsp;&nbsp;<a class="btn btn-danger" onclick="$('#profileForm .reset').click();">Reset</a>
   <p></p>
</form>
                     <div class="modal fade" id="dependentModal" data-keyboard="false">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header"><h5>Add New Dependent</h5></div>
                                <div class="modal-body">
                                    <form id="dependentForm" method="post" enctype="multipart/form-data">
                                       <p>
                                           Type of Dependent<br />
                                           <select class="select2" name="dependentCode" >
                                               <option value="1">Spouse</option>
                                               <option value="2">Child</option>
                                           </select>
                                       </p>
                                       <p>
                                           <input type="text" name="name" placeholder="Dependent's Full name" class="form-control" size="30">
                                       </p>
                                       <p>
                                          <input type="text" class="form-control datepicker" placeholder="Date of Birth" />
                                       </p>
                                       <p>
                                          <select class="select2" name="gender">
                                             <option value="">Gender</option>
                                             <option value="male">Male</option>
                                             <option value="female">Female</option>
                                          </select>
                                       </p>
                                       <p>Dependent's Photograph: <input type="file" name="photo" class="form-control"></p>
                                       <p>&nbsp;</p>
                                       <fieldset>
                                          <legend>Medical Records</legend>
                                          <select name="genotype" class="select2">
                                             <option value="">Genotype</option>
                                             <option value="AA">AA</option>
                                             <option value="AS">AS</option>
                                             <option value="SS">SS</option>
                                          </select>
                                          <br /><br />
                                          <select class="select2" name="bloodGroup">
                                             <option value="">Blood Group</option>
                                             <option value="A+">A+</option>
                                             <option value="A-">A-</option>
                                             <option value="AB+">AB+</option>
                                             <option value="AB-">AB-</option>
                                             <option value="B+">B+</option>
                                             <option value="B-">B-</option>
                                             <option value="O+">O+</option>
                                          </select>
                                          <br />&nbsp;
                                          <p>
                                             Known Medical Condition(s):<br><textarea class="form-control" name="medicalConditions" cols="35"></textarea>
                                          </p>
                                          <input type="text" name="hospitalName" placeholder="Preferred Hospital Name" class="form-control" size="30"><br>
                                          <input type="text" name="hospitalAddress" placeholder="Hospital Address" class="form-control" size="30">
                                       </fieldset>
                                    </form>
                                </div>

                                <div class="modal-footer">
                                    <button class="btn btn-link" onclick="addDependent()" >Add Dependent</button>
                                </div>
                            </div>
                        </div>
                    </div>