
<h4>RATE CARD</h4>

<iframe src="https://onedrive.live.com/embed?cid=EA624C1E88A5EF72&resid=EA624C1E88A5EF72%213410&authkey=ACDl_WzxELlf3I8&em=2" width="100%" height="600" frameborder="0" scrolling="no"></iframe>

<p>&nbsp;</p>
<p>Can't view the Rate Card? <strong>Download it <a href="handbook/rate_card.xlsx" target="_blank">here</a></strong></p>